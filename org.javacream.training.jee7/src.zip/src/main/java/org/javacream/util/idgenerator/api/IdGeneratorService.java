package org.javacream.util.idgenerator.api;

public interface IdGeneratorService {

	public long next();
}
