package org.javacream.books.isbngenerator.api;

public interface IsbnGenerator {

	public abstract String next();

}